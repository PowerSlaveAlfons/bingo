# bingo
A bingo board generator.  

Took Josh's JS web based bingo tool and added some features, like customizable global hotkeys. 

Installation: Be sure to extract it from the zip or itll throw an error. Also be sure to keep a Goals folder next to the .exe as well as a BingoConfig.Xml , Because I didn't test what happens if there are none.   
 

Comes with default GTAVC goals, untested.  



Still need to add antisynergy and glitchiness features as well as other cool stuff (and make it look good.)